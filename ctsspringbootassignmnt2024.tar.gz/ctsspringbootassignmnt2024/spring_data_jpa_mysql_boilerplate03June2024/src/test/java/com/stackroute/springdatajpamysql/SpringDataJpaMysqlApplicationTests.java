package com.stackroute.springdatajpamysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaMysqlApplicationTests {

	@Test
	void contextLoads() {
	}
}
