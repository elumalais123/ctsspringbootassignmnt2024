package com.cts.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpirngLibraryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpirngLibraryManagementApplication.class, args);
	}

}
