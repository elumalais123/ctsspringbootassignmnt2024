package com.cts.auth.enums;

public enum Role {

    USER,ADMIN
}
