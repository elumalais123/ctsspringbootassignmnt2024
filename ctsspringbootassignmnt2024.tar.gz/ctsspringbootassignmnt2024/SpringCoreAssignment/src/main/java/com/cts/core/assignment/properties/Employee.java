package com.cts.core.assignment.properties;

public interface Employee {	
	void work();

}
